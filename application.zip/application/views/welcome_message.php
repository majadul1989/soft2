<?php include_once('header.php'); ?>

<div class="container">
<div class="row">
	<div class="col-md-12">
		<div class="col-md-6">6</div>		
		<div class="col-md-6">6</div>		
	</div>
</div>
</div>



<?php include_once('footer.php'); ?>