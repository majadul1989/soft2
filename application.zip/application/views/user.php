<?php include_once('header.php'); ?>

<div class="container">
<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<form class="form-horizontal">
		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-3 control-label">Email</label>
		    <div class="col-sm-9">
		      <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
		    </div>
		  </div>

		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-3 control-label">Name</label>
		    <div class="col-sm-9">
		      <input type="text" class="form-control" id="inputEmail3" placeholder="Name">
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-3 control-label">NID</label>
		    <div class="col-sm-9">
		      <input type="text" class="form-control" id="inputEmail3" placeholder="NID">
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-3 control-label">Date of Birth</label>
		    <div class="col-sm-9">
		      <input type="text" class="form-control" id="inputEmail3" placeholder="Date of Birth">
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="inputEmail3" class="col-sm-3 control-label">Cell Phone NO</label>
		    <div class="col-sm-9">
		      <input type="text" class="form-control" id="inputEmail3" placeholder="Cell Phone NO">
		    </div>
		  </div>

		  <div class="form-group">
		    <label for="inputPassword3" class="col-sm-3 control-label">Password</label>
		    <div class="col-sm-9">
		      <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="inputPassword3" class="col-sm-3 control-label">Confirm Password</label>
		    <div class="col-sm-9">
		      <input type="password" class="form-control" id="inputPassword3" placeholder="Confirm Password">
		    </div>
		  </div>

		  <div class="form-group">
		    <label for="inputPassword3" class="col-sm-3 control-label"></label>
		    <div class="form-group">
		        <div class="col-md-9 image" id="image">
		            <?php echo $captcha; ?>
		        </div>
		        <div class="col-md-5">
		            <a class="refresh" onclick="refresh()"><img src="<?php echo base_url(); ?>images/refresh.png"> </a>
		        </div>
		    </div>
		  </div>

		  <div class="form-group">
		    <label for="inputPassword3" class="col-sm-3 control-label">Type Captcha</label>
		    <div class="col-sm-9">
		      <input type="text" class="form-control" id="inputPassword3" placeholder="Type Captcha">
		    </div>
		  </div>

		  <div class="form-group">
		    <div class="col-sm-offset-3 col-sm-9">
		      <div class="checkbox">
		        <label>
		          <input type="checkbox"> Remember me
		        </label>
		      </div>
		    </div>
		  </div>
		  <div class="form-group">
		    <div class="col-sm-offset-2 col-sm-9">
		      <button type="submit" class="btn btn-default">Sign in</button>
		    </div>
		  </div>
		</form>	
	</div>
</div>
</div>


<?php include_once('footer.php'); ?>
<script type="text/javascript">
	function refresh(){
		$('.refresh').click(function(){
		    $.ajax({
		        type: 'POST',
		        url: '<?php echo base_url() ?>user/refresh_captcha',
		        success: function(data){
		            if(data){
		                //$('#image').html("adfasdf");
		                alert('asdf');
		            }
		        }
		    })
		});

	}
</script>