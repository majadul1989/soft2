<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->helper('captcha');
		$vals = array(
		        // 'word'          => 'Random word',
		        'img_path'      => './captcha/',
		        'img_url'       => base_url().'captcha/',
		        'font_path'     => FCPATH.'./path/to/fonts/texb.ttf',
		        'img_width'     => 100,
		        'img_height'    => 50,
		        'expiration'    => 7200,
		        'word_length'   => 6,
		        'font_size'     => 30,
		        'img_id'        => 'Imageid',
		        'pool'          => '0123456789',
		        // 'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
		            

		        // White background and border, black text and red grid
		        'colors'  => array(
		                'background' => array(255, 255, 255),
		                'border' => array(255, 0, 0),
		                'text' => array(0, 0, 0),
		               'grid' => array(255, 40, 40)
		        )
		);

		$cap = create_captcha($vals);
		$data['captcha'] = $cap['image']; 
		// $data['captcha'] = $cap; 

		$this->load->view('user', $data);
	}

	public function refresh_captcha(){
	$this->load->helper('captcha');
	$vals = array(
			'img_path' => './captcha/',
			'img_url' => base_url().'captcha/',
			'expiration' => 7200,
			'word_lenght' => 6,
			'font_size' => 22
	);

	$cap = create_captcha($vals);
	$this->session->set_userdata('captchaWord', $cap['word']);
	print_r( $cap['image']);
	}
}